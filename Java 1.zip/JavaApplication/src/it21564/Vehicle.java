/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it21564;

/**
 *
 * @author h
 */
public class Vehicle {

    private int vehicleId;
    private String fuel;
    private int hpower;
    private int size;
    private int cc;
    private float cost;

    public Vehicle(int vehicleId, String fuel, int hpower, int size, int cc, float cost) {
        this.vehicleId = vehicleId;
        this.fuel = fuel;
        this.hpower = hpower;

        this.size = size;
        this.cc = cc;
        this.cost = cost;

    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public int getHpower() {
        return hpower;
    }

    public void setHpower(int hpower) {
        this.hpower = hpower;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        //return this.getVehicleId()+"\t"+this.getFuel()+"\t"+this.getHpower()+"\t"+this.getSize()+"\t"+this.getCC()+"\t"+this.getCost()+"\n";
        return String.format("%d %17s %6d %7d %15d %9.1f", this.getVehicleId(), this.getFuel(), this.getHpower(), this.getSize(), this.getCc(), this.getCost());

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it21564;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author h
 */
public class It21564 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {
        // TODO code application logic here

        List storeList = new ArrayList();
        storeList.add(new Store(1, "κατάστημα", "Ανθέων 32,ΤΚ23456"));
        storeList.add(new Store(2, "κατάστημα", "Σωκράτους 58,ΤΚ13426"));
        storeList.add(new Store(3, "σημείο", "Παπαδιαμαντοπούλου 20,ΤΚ23872"));
        storeList.add(new Store(4, "σημείο", "Παπάγου 3,ΤΚ33421"));

        List<Vehicle> vehicleList = new ArrayList<Vehicle>();
        vehicleList.add(new Vehicle(1, "Βενζίνη", 105, 15, 998, (float) 3.1));
        vehicleList.add(new Vehicle(2, "Ηλεκτρικό", 147, 15, 982, (float) 2.4));
        vehicleList.add(new Vehicle(3, "Βενζίνη", 55, 14, 115, (float) 1.4));
        vehicleList.add(new Vehicle(4, "Βενζίνη", 85, 16, 478, (float) 2.9));
        vehicleList.add(new Vehicle(5, "Ηλεκτρικό", 180, 14, 950, (float) 2.8));
        vehicleList.add(new Car(1, 5, 4, 5, "Βενζίνη", 156, 17, 1499, (float) 3.5));
        vehicleList.add(new Car(2, 2, 2, 3, "Βενζίνη", 89, 15, 1125, (float) 2.6));
        vehicleList.add(new Car(3, 7, 4, 8, "Βενζίνη", 200, 18, 2600, (float) 4.7));
        new date1=new SimpleDateFormat("dd/MM/yyyy hh:mm");
        date1=(22/01/2020 13:00);
        List<Customer> customers = new ArrayList<Customer>();
        customers.add(new Customer("ΑΜ 010500",1234567890,66,823957,8,(float)338.40,"Κάρτα","Παπάγου","σημείο",1,22/01/2020 13:00,25/01/2020 13:00));
        
        int answer = -1;

        while (answer != 0) {

            System.out.println("Καλώς ήρθατε στο σύστημα κράτησης οχημάτων");
            System.out.println("Παρακαλώ επιλέξτε από τα παρακάτω");
            System.out.println("1 για Κράτηση Οχήματος");
            System.out.println("2 για Αλλαγή Κράτησης");
            System.out.println("3 για Εμφάνιση Κράτησης");
            System.out.println("0 για έξοδο από το σύστημα");
            Scanner s = new Scanner(System.in);

            answer = s.nextInt();

            if (answer == 1) {
                Customer customer1 = new Customer();
                Scanner input = new Scanner(System.in);
                System.out.println("Επιλέξτε αν θέλετε δίκυκλο (1) ή αυτοκίνητο (2)");
                s = new Scanner(System.in);
                int answers = s.nextInt();
                String rent = null;
                if (answers == 1) {
                    System.out.println("Επιλέξετε ένα από τα ακόλουθα δίκυκλα");
                    System.out.printf("%6s %6s %6s %6s %6s %6s ", "Id οχήματος", "Καύσιμο ", "Ιπποδύναμη", "Μέγεθος τροχών", "Κυβισμός", "Κόστος ανά ώρα\n");

                    System.out.println("------------------------------------------------------------------------------------------------------");
                    for (Object c : vehicleList) {
                        if (c instanceof Vehicle && !(c instanceof Car)) {
                            System.out.println(c);

                        }

                    }
                    rent = input.nextLine();
                } else if (answers == 2) {
                    System.out.println("Επιλέξετε ένα από τα ακόλουθα αυτοκίνητα");
                    System.out.printf("%6s %6s %6s %6s %6s %6s %6s %6s %6s", "Id οχήματος", "Καύσιμο ", "Ιπποδύναμη", "Μέγεθος τροχών", "Κυβισμός", "Κόστος ανά ώρα", "Πλήθος θέσεων", "Πλήθος θυρών", "Μέγεθος χώρου αποσκευών\n");

                    System.out.println("------------------------------------------------------------------------------------------------------");
                    int i = 0;
                    for (Object c : vehicleList) {
                        if (c instanceof Vehicle && !(c instanceof Car)) {
                            i++;
                        }
                        if (c instanceof Car) {
                            System.out.println(c);

                        }
                    }

                    rent = input.nextLine();
                    rent = Integer.toString(Integer.parseInt(rent) + i);

                }

                customer1.setRentId(Integer.parseInt(rent));
                System.out.println("Δώστε την ημερομηνία παραλαβής και ώρα  στη μορφή dd/MM/yyyy hh:mm");
                String dateInString = input.nextLine();
                Date dateInString1 = new SimpleDateFormat("dd/MM/yyyy hh:mm").parse(dateInString);

                customer1.setDateStart(dateInString1);

                System.out.println("Δώστε την ημερομηνία παράδοσης και ώρα  στη μορφή dd/MM/yyyy hh:mm");
                dateInString = input.nextLine();
                dateInString1 = new SimpleDateFormat("dd/MM/yyyy hh:mm").parse(dateInString);

                customer1.setDateEnd(dateInString1);

                long duration = customer1.getDateEnd().getTime() - customer1.getDateStart().getTime();
                long diffInHours = TimeUnit.MILLISECONDS.toHours(duration);
                //System.out.println(customer1.getDateEnd().getTime());
                //System.out.println(customer1.getDateStart().getTime());
                //long diffInMin = TimeUnit.MILLISECONDS.toMinutes(duration);
                //System.out.println(diffInHours);
                //System.out.println(Math.round((diffInMin /60)* 2) / 2.0);

                customer1.setCost(diffInHours * vehicleList.get(Integer.parseInt(rent) - 1).getCost());

                System.out.println("Δώστε τον τόπο παραλαβής και παράδοσης διαλέγοντας από τους παρακάτω");
                System.out.printf("%s %6s %6s", "Id", "Τύπος ", "Διεύθυνση\n");
                System.out.println("-----------------------------------------------------------------------------");
                for (Object c : storeList) {
                    System.out.println(c);
                }
                String place = input.nextLine();
                customer1.setPlace(place);
                System.out.println("Δώστε τον τύπο του τόπου παραλαβής και παράδοσης (κατάστημα ή σημείο παραλαβής), τρίτη στήλη του παραπάνω πίνακα");
                String type = input.nextLine();
                while (!type.equals("κατάστημα") && !type.equals("σημείο")) {

                    System.out.println("Λάθος δεδομένο. Ο τύπος πρέπει να είναι 'κατάστημα' ή 'σημείο'. Ξαναδοκιμάστε.");
                    type = input.nextLine();
                }

                customer1.setType(type);

                System.out.println("Θα σας ζητηθούν κάποια προσωπικά στοιχεία για την ολοκλήρωση της κράτησης");
                System.out.println("Δώστε τον αριθμό ταυτότητας");

                String id = input.nextLine();
                customer1.setId(id);
                System.out.println("Δώστε τον αριθμό διπλώματος");

                int driveId = Integer.parseInt(input.nextLine());
                customer1.setLicense(driveId);
                System.out.println("Δώστε την ηλικία σας");
                int age = Integer.parseInt(input.nextLine());
                customer1.setAge(age);
                int payment = 0;
                if (customer1.getType() == "κατάστημα") {
                    System.out.println("Επιλέξτε τον τρόπο πληρωμής: μετρητά (1) η πιστωτική/χρεωστική κάρτα (2)");
                    s = new Scanner(System.in);
                    payment = s.nextInt();
                }

                if (payment == 2 || customer1.getType().equals("σημείο")) {
                    System.out.println("Δώστε τον αριθμό της κάρτας σας");
                    int creditCard = Integer.parseInt(input.nextLine());
                    customer1.setCreditCard(creditCard);
                    customer1.setPay("Κάρτα");
                    payment = 2;
                } else {
                    int y = 0;
                    customer1.setCreditCard(y);
                    customer1.setPay("Μετρητά");
                }

                customers.add(customer1);
                System.out.printf("Ο κωδικός κράτησής σας είναι:");
                System.out.println(customers.size());
                customer1.setOrderNum(customers.size());
                System.out.printf("To συνολικό κόστος της κράτησής σας είναι %.2f €\n", customer1.getCost());
                System.out.println();
                if (payment == 2) {
                    System.out.println("Καλείστε να εξοφλήσετε το παραπάνω ποσό με πιστωτική κάρτα");
                    System.out.println("Τα προσωπικά σας στοιχεία είναι:");
                    System.out.println("------------------------------------------------------------------------------------------------------");
                    System.out.printf("%s %6s %6s %6s", "Αριθμός ταυτότητας", "Αριθμός διπλώματος", "Ηλικία", " Αριθμός πιστωτικής κάρτας\n");
                    System.out.printf("%s %12d %6d %8d\n", customer1.getId(), customer1.getLicense(), customer1.getAge(), customer1.getCreditCard());
                } else {
                    System.out.println("Καλείστε να εξοφλήσετε το παραπάνω ποσό με μετρητά");
                    System.out.println("Τα προσωπικά σας στοιχεία είναι:");
                    System.out.println("------------------------------------------------------------------------------------------------------");
                    System.out.printf("%s %6s %6s", "Αριθμός ταυτότητας", "Αριθμός διπλώματος", "Ηλικία\n");
                    System.out.printf("%s %6d %6d\n", customer1.getId(), customer1.getLicense(), customer1.getAge());
                }

                System.out.println("Οι λεπτομέρειες του οχήματός σας είναι:");
                if (answers == 1) {
                    System.out.printf("%6s %6s %6s %6s %6s %6s ", "Id οχήματος", "Καύσιμο ", "Ιπποδύναμη", "Μέγεθος τροχών", "Κυβισμός", "Κόστος ανά ώρα\n");
                } else {
                    System.out.printf("%6s %6s %6s %6s %6s %6s %6s %6s %6s", "Id οχήματος", "Καύσιμο ", "Ιπποδύναμη", "Μέγεθος τροχών", "Κυβισμός", "Κόστος ανά ώρα", "Πλήθος θέσεων", "Πλήθος θυρών", "Μέγεθος χώρου αποσκευών\n");
                }
                System.out.println("------------------------------------------------------------------------------------------------------");
                System.out.println(vehicleList.get(Integer.parseInt(rent) - 1));
            }
            if (answer == 2) {
                System.out.printf("Παρακαλώ εισάγεται τον κωδικό κράτησής σας.\n");
                s = new Scanner(System.in);
                int answers = s.nextInt();
                System.out.println("Μπορείτε να πραγματοποιήσετε αλλαγές στην ημερομηνία και ώρα παράδοσης/παραλαβής και τον τόπο παράδοσης/ παραλαβής");
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Date date = new Date();
                //System.out.println(dateFormat.format(date));
                long duration = customers.get(answers - 1).getDateStart().getTime() - date.getTime();
                long diffInHours = TimeUnit.MILLISECONDS.toHours(duration);
                System.out.println("Πραγματοποιείται αξιολόγηση των δικαιωμάτων σας αλλαγής της κράτησης");
                Scanner input = new Scanner(System.in);
                if (diffInHours < 48) {
                    System.out.println("Επειδή απομένουν λιγότερες από 48 ώρες για την έναρξη της κράτησης, η ακύρωσή της συνεπάγεται με κάποια χρηματική ποινή");
                    System.out.println("Γνωρίζοντας το παραπάνω επιθυμείτε να ακυρώσετε την κράτησή σας;Γράψτε 'Ναι' ή 'Όχι'");
                    String cancel = input.nextLine();
                    if (cancel.equals("Ναι")) {
                        System.out.printf("Η χρηματική σας ποινή είναι η ακόλουθη (30%  επι της αρχικής αξίας ενοικίασης) %.2f €\n", 0.3 * customers.get(answers - 1).getCost());
                    }

                }
                if (diffInHours < 24) {
                    System.out.println("Δεν μπορείτε να αλλάξετε την ημερομηνία παραλαβής διότι απομένουν λίγοτερο από 24 ώρεςγια την έναρξή της");
                    System.out.println("Δώστε την καινούργια ημερομηνία και ώρα  παράδοσης στη μορφή dd/MM/yyyy hh:mm");
                    String dateInString = input.nextLine();
                    Date dateInString1 = new SimpleDateFormat("dd/MM/yyyy hh:mm").parse(dateInString);
                    customers.get(answers - 1).setDateEnd(dateInString1);

                } else {
                    System.out.println("Δώστε την καινούργια ημερομηνία και ώρα παράδοσης στη μορφή dd/MM/yyyy hh:mm");
                    String dateInString = input.nextLine();
                    Date dateInString1 = new SimpleDateFormat("dd/MM/yyyy hh:mm").parse(dateInString);
                    customers.get(answers - 1).setDateStart(dateInString1);

                    System.out.println("Δώστε την καινούργια ημερομηνία και ώρα παραλαβής στη μορφή dd/MM/yyyy hh:mm");
                    dateInString = input.nextLine();
                    dateInString1 = new SimpleDateFormat("dd/MM/yyyy hh:mm").parse(dateInString);
                    customers.get(answers - 1).setDateEnd(dateInString1);

                }

            }
            if (answer == 3) {
                System.out.printf("Παρακαλώ εισάγεται τον κωδικό κράτησής σας.\n");

                s = new Scanner(System.in);
                int answers = s.nextInt();
                System.out.println("Τα στοιχεία σας είναι τα εξής:");
                System.out.println(customers.get(answers - 1));
                System.out.println("Το όχημα της κράτησής σας είναι το εξής:");
                if (vehicleList.get(customers.get(answers - 1).getRentId() - 1) instanceof Car) {
                    System.out.printf("%6s %6s %6s %6s %6s %6s %6s %6s %6s", "Id οχήματος", "Καύσιμο ", "Ιπποδύναμη", "Μέγεθος τροχών", "Κυβισμός", "Κόστος ανά ώρα", "Πλήθος θέσεων", "Πλήθος θυρών", "Μέγεθος χώρου αποσκευών\n");

                } else {
                    System.out.printf("%6s %6s %6s %6s %6s %6s ", "Id οχήματος", "Καύσιμο ", "Ιπποδύναμη", "Μέγεθος τροχών", "Κυβισμός", "Κόστος ανά ώρα\n");
                }
                System.out.println(vehicleList.get(customers.get(answers - 1).getRentId() - 1));

            }
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it21564;

/**
 *
 * @author it21564
 */
public class Store {

    private int id;
    private String type;
    private String address;

    public Store(int id, String type, String address) {
        this.id = id;
        this.type = type;
        this.address = address;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String id) {
        this.type = type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return String.format("%d %8s %6s", this.getId(), this.getType(), this.getAddress(), "\n");

    }

}

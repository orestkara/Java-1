/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it21564;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author it21564
 */
public class NewClass {

    public static void main(String[] args) throws ParseException {

        Customer customer1 = new Customer();
        Scanner input = new Scanner(System.in);
        System.out.println("Δώστε την ημερομηνία παραλαβής στη μορφή dd/MM/yyyy hh:mm");
        String dateInString = input.nextLine();
        Date dateInString1 = new SimpleDateFormat("dd/MM/yyyy hh:mm").parse(dateInString);
        System.out.println(dateInString1);
        customer1.setDateStart(dateInString1);

        //System.out.println("Δώστε την ώρα παραλαβής (ώρα και λεπτά)");
        // System.out.println("Δώστε την ώρα");
        //String tHours = input.nextLine();
        //int tHour = Integer.parseInt(tHours);
        //System.out.println(tHour);
        //System.out.println("Δώστε τα λεπτά");
        //String tMins = input.nextLine();
        //int tMin = Integer.parseInt(tHours);
        System.out.println("Δώστε την ημερομηνία παράδοσης στη μορφή dd/MM/yyyy hh:mm");
        dateInString = input.nextLine();
        dateInString1 = new SimpleDateFormat("dd/MM/yyyy hh:mm").parse(dateInString);
        System.out.println(dateInString1);
        customer1.setDateEnd(dateInString1);
        //SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
        //try {
        //  Date date = formatter.parse(dateInString);
        //System.out.println(date);
        // System.out.println(formatter.format(date));
        // } catch (ParseException e) {

        //System.out.println("Δώστε την ώρα παράδοσης (ώρα και λεπτά)");
        //System.out.println("Δώστε την ώρα");
        //tHours = input.nextLine();
        //tHour = Integer.parseInt(tHours);
        //System.out.println("Δώστε τα λεπτά");
        //tMins = input.nextLine();
        //tMin = Integer.parseInt(tHours);
        long duration = customer1.getDateEnd().getTime() - customer1.getDateStart().getTime();
        long diffInHours = TimeUnit.MILLISECONDS.toHours(duration);
        long diffInMin = TimeUnit.MILLISECONDS.toMinutes(duration);
        System.out.println(diffInHours);
        System.out.println(Math.round((diffInMin /60)* 2) / 2.0);

    }
}

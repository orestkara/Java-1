/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it21564;

import java.util.Date;

/**
 *
 * @author it21564
 */
public class Customer {

    private int orderNum;
    private Date dateStart;
    private Date dateEnd;
    private String id;
    private int license;
    private int age;
    private long creditCard;
    private int rentId;
    private float cost;
    private String pay;
    private String place;
    private String type;
    //private String time;

    public Customer(String id, int license, int age, long creditCard, int rentId, float cost, String pay, String place, String type, int orderNum, Date dateStart, Date dateEnd) {
        this.id = id;
        this.license = license;
        this.age = age;
        this.creditCard = creditCard;
        this.rentId = rentId;
        this.cost = cost;
        this.pay = pay;
        this.place = place;
        this.type= type;
        this.orderNum=orderNum;
        //this.time = time;
        this.dateStart=dateStart;
        this.dateEnd=dateEnd;
    }
    

    public Customer() {
        
    }
    public int getOrderNum(){
        return orderNum;
    }

    public void setOrderNum (int orderNum){
        this.orderNum=orderNum;
    }
    
    public Date getDateStart(){
        return dateStart;
    }
    
    public void setDateStart(Date dateStart){
        this.dateStart=dateStart;
    }
    
    public Date getDateEnd(){
        return dateEnd;
    }
    
    public void setDateEnd(Date dateEnd){
        this.dateEnd=dateEnd;
    }
    
    public String getId(){
        return id;
    }
    
    public void setId(String id){
        this.id=id;
    }
    
    public int getLicense(){
        return license;
    }

    public void setLicense (int license){
        this.license=license;
    }
    
    public int getAge(){
        return age;
    }
    
    public void setAge (int age){
        this.age=age;
    }
    
    public long getCreditCard (){
        return creditCard;
    }
    
    public void setCreditCard (long creditCard){
        this.creditCard=creditCard;
    }
    
    public int getRentId(){
        return rentId;
    }
    
    public void setRentId(int rentId){
        this.rentId=rentId;
    }
    
    public float getCost(){
     return cost;   
    }
    
    public void setCost(float cost){
        this.cost=cost;
    }
    
    public String getPay(){
        return pay;
    }

    public void setPay (String pay ){
        this.pay=pay;
    }
    
    public String getPlace(){
        return place;
    }

    public void setPlace (String place){
        this.place=place;
    }
    
   // public String getTime(){
     //   return time;
   // }

    //public void setTime (String Time){
      //  this.time=time;
    //}
    
    public String getType(){
        return type;
    }

    public void setType(String type) {
        this.type=type;
    }
    
    @Override
    public String toString() {
        
        return String.format("Κωδικός Κράτησης:%d\nId οχήματος κράτησης:%d\nΗμερομηνία παραλαβής:%s\nΗμερομηνία παράδοσης:%s\nΔιεύθυνση Παραλαβής:%s\nΤύπος Παραλαβής:%s\nΤρόπος πληρωμής:%s\nΑριθμός πιστωτικής/χρεωστικής κάρτας:%d\nΚόστος κράτησης:%.2f€\nΗλικία:%d\nΑριθμός ταυτότητας:%s\nΑριθμός διπλώματος οδήγησης:%d\n",this.getOrderNum(),this.getRentId(),this.getDateStart(),this.getDateEnd(),this.getPlace(),this.getType(),this.getPay(),this.getCreditCard(),this.getCost(),this.getAge(),this.getId(),this.getLicense());

    }
    
}

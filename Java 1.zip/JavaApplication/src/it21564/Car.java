/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it21564;

/**
 *
 * @author h
 */
public class Car extends Vehicle {

    public int nseats;/**/
    public int ndoors;
    public int baggage;/**/

    public Car(int vehicleId, int nseats, int nDoors, int baggage, String fuel, int hpower, int size, int cc, float cost) {
        super(vehicleId, fuel, hpower, size, cc, cost);
        this.nseats = nseats;
        this.ndoors = ndoors;
        this.baggage = baggage;

    }

    public int getNseats() {
        return nseats;
    }

    public void setNseats(int nseats) {
        this.nseats = nseats;
    }

    public int getNdoors() {
        return ndoors;
    }

    public void setNdoors(int ndoors) {
        this.ndoors = ndoors;
    }

    public int getBaggage() {
        return baggage;
    }

    public void setBaggage(int baggage) {
        this.baggage = baggage;
    }

    @Override
    public String toString() {
        
        return String.format("%d %17s %6d %7d %16d %9.1f %12d %13d %12d", this.getVehicleId(), this.getFuel(), this.getHpower(), this.getSize(), this.getCc(), this.getCost(),this.getNseats(),this.getNdoors(),this.getBaggage());

    }

}
